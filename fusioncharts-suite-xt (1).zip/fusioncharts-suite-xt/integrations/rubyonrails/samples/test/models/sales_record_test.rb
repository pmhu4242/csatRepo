require 'test_helper'

class SalesRecordTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
